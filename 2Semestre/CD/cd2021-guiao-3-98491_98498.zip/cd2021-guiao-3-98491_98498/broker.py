"""Call broker."""

from src.broker import Broker

if __name__ == "__main__":
    broker = Broker()
    broker.run()
