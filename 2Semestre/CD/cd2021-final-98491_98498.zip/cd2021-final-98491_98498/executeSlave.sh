#!/bin/bash

docker build --tag projecto_final .

docker run -d --name slave1 projecto_final
sleep 1
docker run -d --name slave2 projecto_final
sleep 1

docker logs slave1 -f
#docker logs slave2