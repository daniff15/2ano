#!/bin/bash

./executeServer.sh
echo $''
./executeSlave.sh
