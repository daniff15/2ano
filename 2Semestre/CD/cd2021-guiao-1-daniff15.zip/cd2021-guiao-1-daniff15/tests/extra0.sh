#!/bin/sh

sleep 1
echo "Hello!"
sleep 1
echo "/join #cd"
sleep 2
echo "I'm Joe"
sleep 1
echo "no one is here..."
sleep 1
echo "exit"