#!/bin/sh

echo "Hello!"
sleep 5
echo "exit"
