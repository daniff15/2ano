#!/bin/sh

sleep 1
echo "Hello!"
sleep 3
echo "I'm Joe"
sleep 1
echo "Cya around"
sleep 1
echo "exit"