echo "Olá"
sync
echo "dd tc?"
sync
echo "m/f"
sync
echo "exit"
sync
