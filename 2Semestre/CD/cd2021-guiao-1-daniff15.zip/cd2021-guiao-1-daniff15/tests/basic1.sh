#!/bin/sh

sleep 2
echo "Welcome aboard"
sleep 1
echo "Who are you?"
sleep 1
echo "Nice to meet you Joe"
sleep 2
echo "exit"