echo "Olá!!"
sync
echo "aveiro"
sync
echo "o"
sync
echo "exit"
sync
