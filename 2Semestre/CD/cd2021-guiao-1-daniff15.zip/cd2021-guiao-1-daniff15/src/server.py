"""CD Chat server program."""
import logging
import socket
import selectors
import json

from .protocol import CDProto, CDProtoBadFormat

logging.basicConfig(filename="server.log", level=logging.DEBUG)
clients = {}
channels = [None]

class Server:

    def __init__(self):
        self.sock = socket.socket()
        self.sock.bind(('localhost' , 1235))
        self.sock.listen(100)
        self.sel = selectors.DefaultSelector()
        self.sel.register(self.sock, selectors.EVENT_READ, self.accept)

    def accept(self, sock, mask):
        conn, addr = sock.accept()  # Should be ready
        print('Connection established from', addr)
        clients[conn] = [None] 
        self.sel.register(conn, selectors.EVENT_READ, self.read)

    def read(self, conn, mask):
        try:
            message = CDProto.recv_msg(conn)
            print('echoing', message, 'to', conn)
            logging.debug(message)

            if(message.command == "join"):
                clients[conn].append(message.channel)

                if(None in clients[conn]):
                    clients[conn].remove(None)

            if(message.command == "message"):
                for key , val in clients.items():
                    if(message.channel in val ):
                        CDProto.send_msg(key, message)
                    
        except ConnectionError:
            print('closing', conn)
            del clients[conn]
            self.sel.unregister(conn)
            conn.close()


    """Chat Server process."""
    def loop(self):
        """Loop indefinetely."""
        while True:
            events = self.sel.select()
            for key, mask in events:
                callback = key.data
                callback(key.fileobj, mask)


