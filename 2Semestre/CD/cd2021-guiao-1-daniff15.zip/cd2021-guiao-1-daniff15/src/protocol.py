"""Protocol for chat server - Computação Distribuida Assignment 1."""
import json
from datetime import datetime
from socket import socket


class Message:
    """Message Type."""
    
    def __init__(self, command):
        self.command = command
    
    @classmethod
    def json_encode(cls, command , username: str="" ,channel: str = None, message : str = ""):
        jsontext = {"command" : command}
        jsontext = json.dumps(jsontext)
        return jsontext

    @classmethod
    def json_decode(cls, data):
        self.data = data.decode('utf-8')
        self.data = json.loads(data)
        return data
    
class JoinMessage(Message):
    """Message to join a chat channel."""
    def __init__(self, command, channel):
        super().__init__(command)
        self.channel = channel

    @classmethod
    def json_encode(cls, command, channel=None):
        textmessage = json.loads(super().json_encode(command))
        newfield = {"channel" : channel}
        textmessage.update(newfield)
        return json.dumps(textmessage)

    @classmethod
    def json_decode(cls, data):
        return super().json_decode(data)

    def __str__(self):
        return f"{{\"command\": \"{self.command}\", \"channel\": \"{self.channel}\"}}"

    

class RegisterMessage(Message):
    """Message to register username in the server."""
    def __init__(self, command, username):
        super().__init__(command)
        self.username = username   
        
    def __str__(self):
        #data = json.loads(data)["user"]
        return f"{{\"command\": \"{self.command}\", \"user\": \"{self.username}\"}}"

    @classmethod
    def json_encode(cls, command, username=''):
        textmessage = json.loads(super().json_encode(command))
        newfield = {"user" : username}
        textmessage.update(newfield)
        return json.dumps(textmessage)

    @classmethod
    def json_decode(cls, data):
        return super().json_decode(data)

 
    
class TextMessage(Message):
    """Message to chat with other clients."""
    def __init__(self, command, message , channel):
        super().__init__(command)
        self.message = message
        self.channel = channel

    def __str__(self):
        if(self.channel == None):
            return f"{{\"command\": \"{self.command}\", \"message\": \"{self.message}\", \"ts\": {int(datetime.now().timestamp())}}}"
        else:
            return f"{{\"command\": \"{self.command}\", \"message\": \"{self.message}\", \"channel\": \"{self.channel}\", \"ts\": {int(datetime.now().timestamp())}}}"

    @classmethod
    def json_encode(cls, command, message=''):
        textmessage = json.loads(super().json_encode(command))
        newfield = {"message" : message , "ts" : int(datetime.now().timestamp())}
        textmessage.update(newfield)
        return json.dumps(textmessage)

    @classmethod
    def json_encode2(cls, command, channel,  message=''):
        textmessage = json.loads(super().json_encode(command))
        newfield = {"channel": channel ,"message" : message , "ts" : int(datetime.now().timestamp())}
        textmessage.update(newfield)
        return json.dumps(textmessage)
    
    @classmethod
    def json_decode(cls, data):
        return super().json_decode(data)


class CDProto:
    """Computação Distribuida Protocol."""

    @classmethod
    def register(cls, username: str) -> RegisterMessage:
        """Creates a RegisterMessage object."""
        return RegisterMessage("register", username)

    @classmethod        
    def join(cls, channel: str = None) -> JoinMessage:
        """Creates a JoinMessage object."""
        return JoinMessage("join" , channel)

    @classmethod
    def message(cls, message: str, channel: str = None) -> TextMessage:
        """Creates a TextMessage object."""
        return TextMessage("message" , message, channel)

    @classmethod
    def send_msg(cls, connection: socket, msg: Message):
        """Sends through a connection a Message object.""" 
        if type(msg) is RegisterMessage:
            js = RegisterMessage.json_encode(msg.command, msg.username).encode('utf-8')
        elif type(msg) is JoinMessage:
            js = JoinMessage.json_encode(msg.command, msg.channel).encode('utf-8')
        elif type(msg) is TextMessage:
            if(msg.channel != None):
                js = TextMessage.json_encode2(msg.command, msg.channel ,msg.message).encode('utf-8')
            else:
                js = TextMessage.json_encode(msg.command, msg.message).encode('utf-8')

        header = len(js).to_bytes(2, "big")
        connection.sendall(header + js)

    @classmethod
    def recv_msg(cls, connection: socket) -> Message:
        """Receives through a connection a Message object."""
        conne = connection.recv(2)
        if not conne:
            raise ConnectionError()

        header = int.from_bytes(conne, "big")
        msg = connection.recv(header).decode('utf-8')

        try:
            if (json.loads(msg)["command"] == "register"):
                user = json.loads(msg)["user"]
                message = CDProto.register(user)
                return message

            elif(json.loads(msg)["command"] == "message"):
                textmsg = json.loads(msg)["message"]
                if("channel" in json.loads(msg)):
                    channel = json.loads(msg)["channel"]
                    message = CDProto.message(textmsg,channel)
                    return message
                else:
                    message = CDProto.message(textmsg)
                    return message


            elif(json.loads(msg)["command"] == "join"):
                channel = json.loads(msg)["channel"]
                message = CDProto.join(channel)
                return message

        except:
            raise CDProtoBadFormat()


class CDProtoBadFormat(Exception):
    """Exception when source message is not CDProto."""

    def __init__(self, original_msg: bytes=None) :
        """Store original message that triggered exception."""
        self._original = original_msg

    @property
    def original_msg(self) -> str:
        """Retrieve original message as a string."""
        return self._original.decode("utf-8")
