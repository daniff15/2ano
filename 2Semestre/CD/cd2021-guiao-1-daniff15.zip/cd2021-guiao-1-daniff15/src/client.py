"""CD Chat client program"""
import logging
import socket
import selectors
import sys
import fcntl
import os

from .protocol import CDProto, CDProtoBadFormat


logging.basicConfig(filename=f"{sys.argv[0]}.log", level=logging.DEBUG)
 
class Client:
    """Chat Client process."""

    def __init__(self, name: str = "Foo"):
        
        """Initializes chat client."""
        self.sel = selectors.DefaultSelector()
        self.channel = None
        self.name = name
        self.s = socket.socket()
        

    def connect(self):
        
        self.s.connect(("localhost" , 1235))
        self.sel.register(self.s, selectors.EVENT_READ , self.read)
        """Connect to chat server and setup stdin flags."""
        print("Connection established to Server!")
        msg = CDProto.register(self.name)
        CDProto.send_msg(self.s ,msg)

    def read(self, conn , mask):
        data = CDProto.recv_msg(self.s)
        print(data.message)
        logging.debug(data.message)
        
    def got_keyboard_data(self, stdin , mask):
        inputTxt = stdin.read()

        if inputTxt[0:-1] == "exit": #para excluir o \n
            sys.exit("Exiting...")
        elif inputTxt[0:5] == "/join":
            msg = CDProto.join(inputTxt[6:-1])
            self.channel = inputTxt[6:-1]
            CDProto.send_msg(self.s , msg)
        else :
            message = CDProto.message(inputTxt[0:-1] , self.channel)
            CDProto.send_msg(self.s, message)
            message = CDProto.recv_msg(self.s)
            print(f"< {message.message}")   
            logging.debug(message.message)

    def loop(self):
        """Loop indefinetely."""
        orig_fl = fcntl.fcntl(sys.stdin, fcntl.F_GETFL)
        fcntl.fcntl(sys.stdin, fcntl.F_SETFL, orig_fl | os.O_NONBLOCK)
        self.sel.register(sys.stdin, selectors.EVENT_READ, self.got_keyboard_data)


        while True:
            sys.stdout.write('> ')
            sys.stdout.flush()
            events = self.sel.select()
            for key, mask in events:
                callback = key.data
                callback(key.fileobj, mask)

